# tuc-chess-minMax

Technical University of Crete, school of electrical and computer engineering,
2nd project of the Artificial Intelligence course 
